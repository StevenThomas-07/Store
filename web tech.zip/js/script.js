$(document).ready(function() {
  // Toggle shopping cart display
  $('#cart-btn').click(function() {
      $('.shopping-cart').toggleClass('active');
  });

  // Toggle login form display
  $('#login-btn').click(function() {
      $('.login-form').toggleClass('active');
  });

  // Toggle navbar menu (for smaller screens)
  $('#menu-btn').click(function() {
      $('.navbar').toggleClass('active');
  });

  // Close cart item when 'fa-times' icon is clicked
  $('.shopping-cart .box .fa-times').click(function() {
      $(this).closest('.box').remove();
      updateTotal(); // Function to update total price after removing an item
  });

  // Function to update the total price dynamically
  function updateTotal() {
      let total = 0;
      $('.shopping-cart .box').each(function() {
          const priceText = $(this).find('.price').text().replace('$', '');
          const price = parseFloat(priceText);
          total += price;
      });
      $('.shopping-cart .total span').text(`$${total.toFixed(2)}`);
  }

  // Swiper.js initialization for reviews section
  var swiper = new Swiper('.review-slider', {
      loop: true,
      grabCursor: true,
      spaceBetween: 20,
      pagination: {
          el: '.swiper-pagination',
          clickable: true,
      },
      breakpoints: {
          0: {
              slidesPerView: 1,
          },
          768: {
              slidesPerView: 2,
          },
          1024: {
              slidesPerView: 3,
          },
      },
  });

  // Optional: Remember me checkbox functionality (for example purposes)
  $('#remember-me').change(function() {
      if ($(this).is(':checked')) {
          console.log('User wants to be remembered');
      } else {
          console.log('User does not want to be remembered');
      }
  });
});
